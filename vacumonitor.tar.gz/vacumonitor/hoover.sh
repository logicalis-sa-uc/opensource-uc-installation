#!/bin/sh

# Process files left behind in monitor folder
#30 00 * * * /home/opsmail/bin/hoover.sh >/home/opsmail/log/hoover.log 2>&1

/usr/bin/find /var/spool/asterisk/monitor/ -name "*.wav" -mmin +60 | xargs -I{} /bin/su -  -c "/home/opsmail/bin/vacumonitor.sh --fix {}"

exit 0
