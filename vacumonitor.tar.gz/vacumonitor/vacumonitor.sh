#!/bin/sh

## Vacumonitor.sh: Vacuum the Asterisk Monitor directory
## Copyright (c) 2013 Clarotech Holdings (Pty) Ltd.  All Rights Reserved.
## No part of this software may be copied, stored, electronically or in any
## form, made available or distributed, reproduced or commercially benefitted
## from reproduced, distributed or used without the prior written permission
## of Clarotech Holdings (Pty) Ltd.

## $LastChangedRevision: 1103 $
## $LastChangedDate: 2014-08-20 16:50:22 +0200 (Wed, 20 Aug 2014) $
## $LastChangedBy: author $

############################################################
### You should not need to change anything in this file! ###
### If any client-specific changes are required, first   ###
### speak to technical!                                  ###
############################################################
### If any client-specific customisations are made,      ###
### describe the changes here:                           ###
###                                                      ###
###                                                      ###
###                                                      ###
############################################################

CURRUSER=`whoami`
#if [ x${CURRUSER} != xasterisk ]
#then
#  echo "You must run vacumonitor as the asterisk user."
#  exit 1
#fi

if [ x${1} = x ]
then
  echo "No parameters specified."
  exit 1
fi

### Get OpsMail configuration ###
. /usr/local/etc/opsmail.conf

### Start in Asterisk monitor folder ###
cd /var/spool/asterisk/monitor

### Running fix? ###

if [ x${1} = x--fix ]
then
  FIXREC=YES
  shift
  cmdline="${@}"
  filedate=`stat -c %y "${cmdline}" | sed 's/^\([0-9\-]*\).*/\1/'`
  if [ $? -ne 0 ]
  then
    echo "Stat failure - exiting."
        exit 1
  fi
  fileyear=`echo ${filedate} | sed 's/^\([0-9]*\).*/\1/'`
  filemonth=`echo ${filedate} | sed 's/^[0-9]*\-\([0-9]*\).*/\1/'`
  fileday=`echo ${filedate} | sed 's/^[0-9]*\-[0-9]*\-\([0-9]*\).*/\1/'`
  recpath=`echo "${@}" | sed 's/.[^.]*$//'`
  DATE="${fileyear}/${filemonth}/${fileday}"
else
  FIXREC=NO
  DATE=`/bin/date "+%Y/%m/%d"`
  recpath="${1}"
fi

### Process OneTouch Recording ###

if [ "x${recpath}" = "x^{MONITOR_FILENAME}" ]
then
  log "Was called from Monitor!?!?!"
  filename=`basename $2 | sed "s/-in.wav//"`
  log "Wants me to process ${filename}..."
  /usr/local/bin/sox -m ${filename}-in.wav ${filename}-out.wav ${filename}.wav
  rm -f ${filename}-in.wav ${filename}-out.wav
  recfile=${filename}
  PREFIX=onetouch
  #mail -s "OneTouch recording processed"
fi

### Get vacumonitor config ###

if [ -f ${OPSMAILETC}/vacumonitor.conf ]
then
  . ${OPSMAILETC}/vacumonitor.conf
else
  echo "FATAL ERROR: Vacumonitor config not found."
  exit 1
fi

### Define functions ###

log() {
  if [ x${DEBUG} = xYES ]
  then
    echo "`date` [$$] NOTICE: ${1}" >> ${LOGFILE}
  fi
}

elog() {
  echo "`date` [$$] ERROR: ${1}" >> ${ERRORLOG}
  echo "`date` [$$] ERROR: ${1}" >> ${LOGFILE}
  exit 1
}

### Some Checks ###

testpath=`echo ${recpath} | tr -d '* ():;'`
if [ "x${testpath}" != "x${recpath}" ]
then
  log "Renaming ${recpath} to ${testpath}"
  mv "${recpath}.wav" ${testpath}.wav
  if [ $? -ne 0 ]
  then
    elog "mv \"${recpath}.wav\" ${testpath.wav}"
  fi
  sqlfix="UPDATE recording_log SET filename='${testpath}' WHERE filename='${recpath}'"
  recpath=${testpath}
else
  sqlfix=""
fi

if [ x${MONITORDATES} = xYES ]
then
  if [ x${FIXREC} = xYES ]
  then
    recfile=${recpath}
  else
    recdate=$(date +%Y/%m/%d)
	recfile=${recdate}/${recpath}
  fi
  baserecfile=`basename ${recpath}`
else
  recfile=`basename ${recpath}`
  baserecfile=${recfile}
fi

##### Start main program #####

if [ x${FIXREC} = xYES ]
then
 log "Start processing FIX for ${recpath}"
else
 log "Start processing normally for ${recpath}"
fi

if [ ! -d ${TARGET} ]
then
  mkdir -p ${TARGET}
  if [ $? -ne 0 ]
  then
    elog "Creating directory ${TARGET}"
  fi
  chown asterisk:asterisk ${TGTBASE}/${PREFIX}/`/bin/date "+%Y"`
  chmod 755 ${TGTBASE}/${PREFIX}/`/bin/date "+%Y"`
  chown asterisk:asterisk ${TGTBASE}/${PREFIX}/`/bin/date "+%Y/%m"`
  chmod 755 ${TGTBASE}/${PREFIX}/`/bin/date "+%Y/%m"`

  chown asterisk:asterisk ${TARGET}
  if [ $? -ne 0 ]
  then
        elog "chown asterisk:asterisk ${TARGET}"
  fi

  chmod 755 ${TARGET}
  if [ $? -ne 0 ]
  then
    elog "chmod 755 ${TARGET}"
  fi

  if [ x${RHOST} != x ]
  then
    SSHMKDIR=YES
    log "Create remote ${RTARGET}"
    /usr/bin/ssh ${RHOST} mkdir -p ${RTARGET} 2>> ${LOGFILE}
    if [ $? -ne 0 ]
    then
          elog "SSH mkdir failure"
    fi
  fi

fi

if [ -f ${TARGET}/${recfile}.* ]
then
  elog "File exists at target: ${TARGET}/${recfile}.*"
fi

if [ -f ${recfile}.* ]
then
  log "Move ${recfile} to ${TARGET}/"

  if [ x${RECFORMAT} = xmp3 ]
  then
    nice -n 10 /usr/bin/lame --silent --preset phone ${recfile}.wav ${TARGET}/${baserecfile}.mp3
    if [ $? -ne 0 ]
    then
      elog "FATAL: lame ${recfile}.* ${TARGET}"
    else
      rm ${recfile}.wav
      if [ $? -ne 0 ]
      then
        log "WARNING: Cannot remove source file."
      fi
    fi

  elif [ x${RECFORMAT} = xogg ]
  then
    /usr/local/bin/sox ${recpath}.* ${TARGET}/${baserecfile}.ogg
    if [ $? -ne 0 ]
    then
      elog "FATAL: sox ${recfile}.* ${TARGET}"
     else
      rm ${recfile}.wav
    fi


  else
    mv ${recfile}.* ${TARGET}/
    if [ $? -ne 0 ]
    then
      elog "mv ${recfile}.* ${TARGET}/"
    fi

  fi

  recfile=${baserecfile}

  chmod 644 ${TARGET}/${recfile}.*

  if [ x${RHOST} != x ]
  then

    log "/usr/bin/scp -p ${TARGET}/${recfile}.* ${RHOST}:${RTARGET}/"
    /usr/bin/scp -p ${TARGET}/${recfile}.* ${RHOST}:${RTARGET}/

    if [ $? -ne 0 ]
        then

      if [ x${SSHMKDIR} != xYES ]
      then
        log "DOUBLECHECK: Create remote ${RTARGET}"
        /usr/bin/ssh ${RHOST} mkdir -p ${RTARGET} 2>> ${LOGFILE}
        if [ $? -ne 0 ]
        then
              elog "SSH mkdir failure"
        fi
                log "RETRY: /usr/bin/scp -p ${TARGET}/${recfile}.* ${RHOST}:${RTARGET}/"
        /usr/bin/scp -p ${TARGET}/${recfile}.* ${RHOST}:${RTARGET}/
        if [ $? -ne 0 ]
            then
          elog "FATAL ERROR: SCP failure."
            fi
      fi

        fi

        rm ${TARGET}/${recfile}.*

  fi

  if [ x${VDTARGET} != x ]
  then
  
    if [ "x${sqlfix}" != "x" ]
	then
	  log "SQL update (rename fix): ${sqlfix}"
	  UPDATERESULT=$(mysql -u${VARDB_user} -p${VARDB_pass} -h${VARDB_server} -e "${sqlfix}" -sN ${VARDB_database})
	fi

    UPDATESQL="UPDATE recording_log SET location = '${VDTARGET}/${recfile}.${RECFORMAT}' WHERE filename='${recfile}'"
    log "SQL update: ${UPDATESQL}"
    UPDATERESULT=$(mysql -u${VARDB_user} -p${VARDB_pass} -h${VARDB_server} -e "${UPDATESQL}" -sN ${VARDB_database})

  fi

else
  log "Source file ${recfile}.* not found."
fi

log "End"
exit 0
